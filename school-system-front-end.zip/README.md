# School System Fron-end

## To get starting run the following code

```
git clone https://github.com/bnjamel/school-system-front-end.git
cd school-system-front-end
npm install
npm run dev
```
